"""Simple visual interface for the PNGJL competitive-scoring graph."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import streamlit as st

from competitive_scoring.config import Settings
from competitive_scoring.graph import run_research
from competitive_scoring.rag import BookKnowledgeBase

st.set_page_config(page_title="PNGJL Competitive Scoring", page_icon="💎", layout="wide")

st.title("💎 PNGJL Competitive Investment Scoring")
st.caption("LangGraph research pipeline · You.com primary search · local Peaceful Investing RAG")

with st.sidebar:
    st.header("Run settings")
    mode = st.radio(
        "Data mode",
        ("demo", "live"),
        help="Demo is deterministic and offline. Live requires You.com and OpenAI keys in .env.",
    )
    st.text_input("Target", value="P N Gadgil Jewellers (PNGJL)", disabled=True)
    st.text_input("Horizon", value="2–3 years", disabled=True)
    st.info("‘RSA’ is interpreted as the standard Wilder RSI(14).")

    settings = Settings.from_env(mode=mode)  # type: ignore[arg-type]
    previous_mode = st.session_state.get("_selected_mode")
    if previous_mode is not None and previous_mode != mode:
        # Never display an old demo result under a live-mode banner (or vice
        # versa) after the user changes the radio button.
        st.session_state.pop("briefing", None)
        st.session_state.pop("trace", None)
    st.session_state["_selected_mode"] = mode
    if settings.book_pdf_path.exists():
        st.success(f"Private book found: {settings.book_pdf_path.name}")
    else:
        st.error("Book not found. Set BOOK_PDF_PATH in .env.")

    if st.button("Build / refresh private book index", width="stretch"):
        try:
            with st.spinner("Reading the book locally and building Chroma…"):
                result = BookKnowledgeBase(
                    pdf_path=settings.book_pdf_path,
                    index_dir=settings.book_index_dir,
                ).ensure_index(force=True)
            st.success(f"Indexed {result['pages']} pages into {result['chunks']} chunks.")
        except Exception as exc:  # noqa: BLE001 - UI boundary displays actionable failures.
            st.exception(exc)

    run_clicked = st.button("Run all agents", type="primary", width="stretch")

architecture_path = (
    Path(__file__).parent / "pngjl-competitive-investment-scoring-architecture-final.png"
)
with st.expander("See the sequential / parallel architecture", expanded=False):
    if architecture_path.exists():
        st.image(str(architecture_path), width="stretch")

if mode == "demo":
    st.warning(
        "Demo mode uses invented values. It proves the software flow only and must not be "
        "used for an investment decision."
    )
else:
    st.info(
        "Live results are time-sensitive research, not personal financial advice. Confirm every "
        "important value in the linked exchange/company source."
    )

if run_clicked:
    # If this run fails, the previous result must not remain on screen and look
    # like it belongs to the newly requested run.
    st.session_state.pop("briefing", None)
    st.session_state.pop("trace", None)
    try:
        with st.spinner(
            "Running peer discovery → parallel company research → book RAG → audit → ranking…"
        ):
            briefing, trace = run_research(settings)
        st.session_state["briefing"] = briefing
        st.session_state["trace"] = trace
    except Exception as exc:  # noqa: BLE001 - UI boundary displays actionable failures.
        st.error("The workflow stopped instead of silently substituting data.")
        st.exception(exc)

briefing = st.session_state.get("briefing")
trace = st.session_state.get("trace", [])

if briefing:
    st.subheader("Result")
    st.write(briefing.conclusion)

    rows = []
    for item in briefing.companies:
        rows.append(
            {
                "Rank": item.rank,
                "Ticker": item.research.company.ticker,
                "Core": item.research.core_score,
                "Book": item.book_score.total_score,
                "Final": item.final_score,
                "Confidence": item.research.confidence,
                "Book coverage": item.book_score.coverage_weight / 100,
            }
        )
    frame = pd.DataFrame(rows).set_index("Rank")
    st.dataframe(
        frame,
        width="stretch",
        column_config={
            "Confidence": st.column_config.ProgressColumn(
                format="percent", min_value=0, max_value=1
            ),
            "Book coverage": st.column_config.ProgressColumn(
                format="percent", min_value=0, max_value=1
            ),
        },
    )

    tabs = st.tabs([item.research.company.ticker for item in briefing.companies])
    for tab, item in zip(tabs, briefing.companies):
        with tab:
            left, right = st.columns((1, 1))
            with left:
                st.markdown("#### Stage 2 evidence scores")
                core_text = (
                    f"{item.research.core_score:.2f}/100"
                    if item.research.core_score is not None
                    else "Not scored"
                )
                st.metric("Core Score", core_text)
                st.write(f"**Business:** {item.research.business.summary}")
                st.write(f"**Fundamentals:** {item.research.fundamentals.summary}")
                st.write(f"**Management:** {item.research.management.summary}")
                st.write(f"**Valuation:** {item.research.valuation.summary}")
                st.write(f"**Technicals:** {item.research.technicals.summary}")
            with right:
                st.markdown("#### Stage 3 private-book alignment")
                book_rows = []
                for category in item.book_score.categories:
                    pages = ", ".join(
                        f"p.{citation.printed_page} / PDF {citation.pdf_page}"
                        for citation in category.book_basis
                    )
                    book_rows.append(
                        {
                            "Category": category.label,
                            "Score /5": category.score,
                            "Weight": f"{category.weight}%",
                            "Book pages": pages or "Unresolved",
                        }
                    )
                st.dataframe(pd.DataFrame(book_rows), hide_index=True, width="stretch")

            st.markdown("#### Sources")
            for source in item.research.sources:
                qualifier = " _(reference only in demo)_" if briefing.mode == "demo" else ""
                st.markdown(f"- [{source.title}]({source.url}){qualifier}")

    with st.expander("Agent execution trace"):
        for event in trace:
            st.write(f"`{event.stage}` **{event.agent}** — {event.detail}")

    with st.expander("Evidence audit"):
        st.write(f"Passed: **{briefing.audit.passed}**")
        for finding in briefing.audit.findings:
            st.write(f"- {finding.severity.upper()} `{finding.code}` — {finding.message}")

    col1, col2 = st.columns(2)
    with col1:
        st.download_button(
            "Download Markdown briefing",
            data=briefing.markdown,
            file_name="pngjl_competitive_scoring_briefing.md",
            mime="text/markdown",
            width="stretch",
        )
    with col2:
        st.download_button(
            "Download structured JSON",
            data=json.dumps(briefing.model_dump(mode="json"), indent=2),
            file_name="pngjl_competitive_scoring_briefing.json",
            mime="application/json",
            width="stretch",
        )

    st.caption(briefing.disclaimer)
else:
    st.write("Choose a mode and click **Run all agents** to create the first briefing.")
