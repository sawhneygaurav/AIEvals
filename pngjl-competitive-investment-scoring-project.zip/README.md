# PNGJL Competitive Investment Scoring

A beginner-readable LangGraph project that compares **P N Gadgil Jewellers Limited
(NSE: PNGJL)** with three listed jewellery peers, adds a 2–3 year investment
research angle, and applies a private, page-cited framework from *Peaceful
Investing*.

> This is an educational research system—not personal financial advice. Demo
> values are invented. Live values are time-sensitive and must be checked against
> primary filings before any investment decision.

![Hand-drawn workflow](pngjl-competitive-investment-scoring-architecture-final.png)

## What is implemented

There are ten logical agents:

1. Orchestrator
2. Peer Discovery
3. Web + News Research (You.com)
4. Business Analyst
5. Fundamentals + Growth Analyst
6. Management Analyst
7. Valuation Analyst
8. Technical Analyst (SMA20, SMA50, Wilder RSI14)
9. Peaceful Investing Book RAG Scorer
10. Evidence Auditor

The exact execution order is:

```text
SEQUENTIAL: Orchestrator → Peer Discovery

PARALLEL across PNGJL + three peers:
  Sources first
    → Business ┐
    → Fundamentals ├─ JOIN ALL → Valuation
    → Management   │
    → Technicals ┘

SEQUENTIAL BARRIER: wait for all four company valuations

PARALLEL: four private-book RAG scores
  → JOIN ALL → Evidence audit → optional targeted retry (maximum 2)

SEQUENTIAL: deterministic final score → ranked briefing
```

Valuation waits for **Business, Fundamentals, Management, and Technicals**. The
four-input join is visible in `build_company_subgraph()` in
`src/competitive_scoring/graph.py`.

## Scoring

The arithmetic is code, not an LLM opinion:

```text
Core = Fundamentals 25% + Growth 20% + Valuation 25%
     + Management 20% + Technicals 10%

Final = Core 80% + Peaceful Investing Book Alignment 20%
```

The Book Alignment Score has six fixed categories: financial strength (20),
earnings/cash quality (20), moat and self-funded growth (20), management and
capital allocation (20), valuation/margin of safety (15), and credit/downside
resilience (5). Every category needs both:

- a resolved book chunk with printed and PDF page numbers; and
- current company evidence from a dated external source.

If covered weight is below 80%, the book total is `null`, not an invented neutral
score. The book provides methodology; it never proves a current company fact.

Missing evidence is never converted into an average score. If any required
Fundamentals/Growth/Valuation/Management/Technicals component is unsupported,
that company remains in the briefing as **Not scored** and receives no rank. If
the evidence audit itself fails, all final scores are suppressed and the report
contains diagnostics instead of declaring a winner.

## Why the book uses local RAG—not memory or Pinecone

This is one private 271-page book. A local persistent Chroma index is simpler,
cheaper, and more private than a hosted vector database. The implementation uses
a deterministic local hashing embedder, so it downloads no embedding model and
needs no embedding API key. The PDF and derived index live under ignored paths.

The book is **not copied into this repository**. On this computer the app can find
the attached licensed copy at:

```text
~/Documents/DrVijay/Ebook-Peaceful-Investing.pdf
```

For another computer, put a licensed copy in `data/private/` or set
`BOOK_PDF_PATH`. Do not upload the PDF or `data/private/` to GitHub.

## Quick start

Python 3.11+ is required. These commands use the Python 3.12 installation found
on the current machine:

```bash
/opt/anaconda3/bin/python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -e ".[dev]"
cp .env.example .env
```

Build the private book index once:

```bash
.venv/bin/competitive-scoring ingest-book
```

Run the deterministic offline demo:

```bash
.venv/bin/competitive-scoring run --mode demo
```

Open the interface:

```bash
.venv/bin/streamlit run streamlit_app.py
```

The CLI writes `outputs/briefing.md` and `outputs/briefing.json`. Streamlit also
offers both as download buttons.

## Live mode

Add keys to `.env`:

```dotenv
YDC_API_KEY=...
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5-mini
APP_MODE=live
```

Then run:

```bash
.venv/bin/competitive-scoring run --mode live
```

Live mode does **not** silently fall back to demo data. If a key, search result,
or required source is missing, the workflow stops or lowers evidence coverage.

`RESEARCH_AS_OF` can pin a historical run. If it is blank, demo mode uses its
frozen sample date while live mode uses the current date. Search freshness,
publication dates, market-price requests, and metric dates are checked against
that cutoff to prevent accidental look-ahead.

- You.com uses the current `POST https://ydc-index.io/v1/search` endpoint and
  `X-API-Key` authentication.
- Web/news results carry query, search UUID, URL, publication age, and retrieval
  timestamp into the evidence model.
- You.com and OpenAI calls use bounded retries for transient failures; successful
  search categories are retained if another category fails.
- OpenAI is used only to extract structured live evidence. The local book policy
  and final arithmetic are deterministic. Book chunks are not sent to the LLM.
- Daily prices are requested only through the research date, prefer adjusted
  close, retain the exact request URL, and are used locally for SMA20/SMA50 and
  Wilder RSI(14). You.com remains the primary company/web/news research source.

Relevant official docs: [You.com Web Search API](https://you.com/docs/api-reference/search/v1-search),
[LangGraph graph API](https://docs.langchain.com/oss/python/langgraph/graph-api),
and [OpenAI Responses API](https://developers.openai.com/api/reference/cli/resources/responses/methods/create).

## Project map

```text
streamlit_app.py                    visual interface
src/competitive_scoring/
  graph.py                          sequential/parallel LangGraph orchestration
  agents.py                         the ten agent behaviors
  models.py                         validated data passed between agents
  scoring.py                        fixed Core and Final formulas
  rag.py                            private local PDF → Chroma index → retrieval
  book_policy.py                    six-category page-cited book policy
  llm.py                            optional live structured extraction
  report.py                         Markdown briefing renderer
  demo_data.py                      explicitly illustrative offline fixture
  tools/you_search.py               official You.com Search API adapter
  tools/market_data.py              SMA20/SMA50/RSI14 calculations
tests/                              offline unit and graph tests
```

## Beginner tour

Start in `streamlit_app.py`. Its **Run all agents** button calls `run_research()`.
Next read `graph.py`: edges show what is sequential and what is parallel. Open
`agents.py` to see the work performed by each node. Finally inspect `scoring.py`
and `book_policy.py`; that is where the reproducible formulas and guardrails live.

The code contains comments around decisions and boundaries—not comments that
merely repeat the next line—so a novice can follow why each step exists.
