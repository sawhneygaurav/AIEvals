"""Application configuration.

Keeping settings in one small module makes it obvious which values are secrets,
which values are fixed policy, and which values a user may safely change.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Literal

from dotenv import load_dotenv

Mode = Literal["demo", "live"]


def _project_root() -> Path:
    """Return the repository root regardless of the current shell directory."""

    return Path(__file__).resolve().parents[2]


def _default_book_path() -> Path:
    """Find the attached private book without copying it into the repository."""

    configured = os.getenv("BOOK_PDF_PATH", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()

    # This is the location of the PDF attached in the current workspace session.
    attached = Path.home() / "Documents" / "DrVijay" / "Ebook-Peaceful-Investing.pdf"
    if attached.exists():
        return attached

    # A collaborator can instead put their own licensed copy here.  The folder
    # is ignored by Git, so neither the PDF nor its derived index is published.
    return _project_root() / "data" / "private" / "Ebook-Peaceful-Investing.pdf"


@dataclass(frozen=True, slots=True)
class Settings:
    """Runtime settings shared by the Streamlit app, CLI, and tests."""

    mode: Mode = "demo"
    target_symbol: str = "PNGJL"
    target_name: str = "P N Gadgil Jewellers Limited"
    peer_count: int = 3
    horizon: str = "2-3 years"
    research_as_of: date = date(2026, 9, 2)
    book_pdf_path: Path = Path("data/private/Ebook-Peaceful-Investing.pdf")
    book_index_dir: Path = Path("data/private/peaceful_investing_chroma")
    ydc_api_key: str | None = None
    openai_api_key: str | None = None
    openai_model: str = "gpt-5-mini"
    max_audit_retries: int = 2
    max_workers: int = 4

    @classmethod
    def from_env(cls, *, mode: Mode | None = None) -> Settings:
        """Load settings from `.env` plus the process environment.

        Explicit process variables win over values in `.env`, which is the
        conventional and least surprising behavior for local development.
        """

        load_dotenv(override=False)
        project_root = _project_root()
        index_text = os.getenv("BOOK_INDEX_DIR", "data/private/peaceful_investing_chroma")
        index_path = Path(index_text).expanduser()
        if not index_path.is_absolute():
            index_path = project_root / index_path

        chosen_mode = mode or os.getenv("APP_MODE", "demo").lower().strip()
        if chosen_mode not in {"demo", "live"}:
            raise ValueError("APP_MODE must be either 'demo' or 'live'.")

        # Demo output is intentionally frozen so screenshots and tests remain
        # reproducible.  Live research defaults to today and can be pinned to a
        # historical cutoff with RESEARCH_AS_OF.
        configured_as_of = os.getenv("RESEARCH_AS_OF", "").strip()
        default_as_of = (
            date(2026, 9, 2) if chosen_mode == "demo" else datetime.now(UTC).date()
        )

        return cls(
            mode=chosen_mode,  # type: ignore[arg-type]
            target_symbol=os.getenv("TARGET_SYMBOL", "PNGJL").upper().strip(),
            target_name=os.getenv("TARGET_NAME", "P N Gadgil Jewellers Limited").strip(),
            research_as_of=(
                date.fromisoformat(configured_as_of) if configured_as_of else default_as_of
            ),
            book_pdf_path=_default_book_path(),
            book_index_dir=index_path.resolve(),
            ydc_api_key=os.getenv("YDC_API_KEY") or None,
            openai_api_key=os.getenv("OPENAI_API_KEY") or None,
            openai_model=os.getenv("OPENAI_MODEL", "gpt-5-mini").strip(),
            max_audit_retries=int(os.getenv("MAX_AUDIT_RETRIES", "2")),
            max_workers=max(1, int(os.getenv("MAX_WORKERS", "4"))),
        )

    def validate_for_run(self) -> None:
        """Fail early with a useful message instead of failing deep in an agent."""

        if not self.book_pdf_path.exists():
            raise FileNotFoundError(
                "Peaceful Investing PDF was not found. Set BOOK_PDF_PATH in .env "
                f"(checked: {self.book_pdf_path})."
            )
        if self.mode == "live":
            missing = []
            if not self.ydc_api_key:
                missing.append("YDC_API_KEY")
            if not self.openai_api_key:
                missing.append("OPENAI_API_KEY")
            if missing:
                raise ValueError("Live mode needs: " + ", ".join(missing))
