"""Small structured-output wrapper around the OpenAI Responses API.

Only live mode uses this class.  Demo mode deliberately runs without an API key
so a learner can inspect the full orchestration before paying for API calls.
"""

from __future__ import annotations

import json
from typing import Any, TypeVar

from openai import OpenAI, OpenAIError
from pydantic import BaseModel, ValidationError

SchemaT = TypeVar("SchemaT", bound=BaseModel)


# A retry is useful for two different transient failures:
#
# 1. The HTTP request can fail (for example, a brief connection problem).
# 2. The model can finish without producing JSON that our Pydantic model accepts.
#
# We deliberately keep this to two attempts.  It gives a transient problem one
# chance to recover without allowing one graph node to loop indefinitely or run
# up an unexpected API bill.
DEFAULT_MAX_ATTEMPTS = 2

REPAIR_INSTRUCTION = """\
A previous attempt did not produce a complete response that matched the required
JSON schema. Return exactly one complete JSON object. Include every required
field, use the declared data types, and do not add prose outside the JSON object.
"""


class StructuredLLM:
    """Ask a model for JSON and validate it against a Pydantic schema."""

    def __init__(
        self,
        *,
        api_key: str,
        model: str,
        client: Any | None = None,
        max_attempts: int = DEFAULT_MAX_ATTEMPTS,
    ) -> None:
        """Create the small API wrapper.

        ``client`` is optional in the application, but accepting it makes the
        network boundary easy to test with a fake client.  Production callers
        simply omit it and receive the normal OpenAI SDK client.
        """

        if max_attempts < 1:
            raise ValueError("max_attempts must be at least 1")

        self._client = client if client is not None else OpenAI(api_key=api_key)
        self.model = model
        self.max_attempts = max_attempts

    def generate(
        self,
        *,
        schema: type[SchemaT],
        instructions: str,
        prompt: str,
    ) -> SchemaT:
        """Return validated structured output, retrying once when necessary.

        A response is usable only when the API marks it ``completed``, it has
        non-blank text, the text is valid JSON, and Pydantic accepts the JSON.
        Failed API calls and all four output failures receive the same bounded
        retry treatment.
        """

        last_error: Exception | None = None

        for attempt_number in range(1, self.max_attempts + 1):
            attempt_instructions = instructions
            if attempt_number > 1:
                # The JSON schema is still supplied to the API below.  This short
                # note tells the model why it is being asked again and focuses the
                # repair on completeness and schema adherence.
                attempt_instructions = f"{instructions.rstrip()}\n\n{REPAIR_INSTRUCTION}"

            try:
                # `store=False` is intentional on *every* attempt.  The response
                # is used only for this graph run and is not retained by the API
                # as application conversation state.
                response = self._client.responses.create(
                    model=self.model,
                    instructions=attempt_instructions,
                    input=prompt,
                    store=False,
                    text={
                        "format": {
                            "type": "json_schema",
                            "name": schema.__name__.lower(),
                            "schema": schema.model_json_schema(),
                            "strict": False,
                        }
                    },
                )

                status = getattr(response, "status", None)
                if status != "completed":
                    details = getattr(response, "incomplete_details", None)
                    detail_suffix = f" Details: {details!r}." if details is not None else ""
                    raise RuntimeError(
                        f"The model response status was {status!r}, not 'completed'."
                        f"{detail_suffix}"
                    )

                output_text = getattr(response, "output_text", None)
                if not isinstance(output_text, str) or not output_text.strip():
                    raise RuntimeError("The model returned no structured text.")

                # Parsing and Pydantic validation are kept inside the retry block.
                # Malformed JSON and correctly formed but schema-invalid JSON can
                # therefore both be repaired by the second model attempt.
                payload = json.loads(output_text)
                return schema.model_validate(payload)
            except (OpenAIError, json.JSONDecodeError, ValidationError, RuntimeError) as error:
                last_error = error
                if attempt_number == self.max_attempts:
                    break

        # ``max_attempts`` is validated above, so reaching this line guarantees
        # that ``last_error`` was set during the final failed attempt.
        assert last_error is not None
        raise RuntimeError(
            f"Structured model output failed after {self.max_attempts} attempts: "
            f"{last_error}"
        ) from last_error
