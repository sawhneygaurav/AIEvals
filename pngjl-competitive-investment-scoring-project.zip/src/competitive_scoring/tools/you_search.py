"""Small, typed adapter for the You.com Web Search API.

The rest of the application should not need to know how API keys, HTTP requests,
or optional response fields work.  It can call :class:`YouSearchClient` and work
with the plain dataclasses returned here.

This module intentionally uses only Python's standard library.  Keeping the
transport small makes the adapter easy to test and avoids requiring the
official SDK merely to make one endpoint call.
"""

from __future__ import annotations

import json
import os
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

# You.com documents POST as the current endpoint.  GET remains backwards
# compatible, but newer features such as ``extraction`` are POST-only.
YOU_SEARCH_ENDPOINT = "https://ydc-index.io/v1/search"
YOU_API_KEY_ENV_VAR = "YDC_API_KEY"


class YouSearchError(RuntimeError):
    """Raised when a You.com request cannot produce a valid response."""


class YouSearchConfigurationError(YouSearchError):
    """Raised for missing credentials or invalid request options."""


@dataclass(frozen=True)
class SourceTrace:
    """Provenance shared by every result returned from one search call.

    ``search_uuid`` is supplied by You.com and is useful when troubleshooting a
    particular search. ``retrieved_at`` is generated locally because a search
    response does not itself state when our application received it.
    """

    provider: str
    endpoint: str
    query: str
    search_uuid: str | None
    latency_seconds: float | None
    retrieved_at: str


@dataclass(frozen=True)
class SearchContents:
    """Optional extracted content attached to a web or news result."""

    highlights: tuple[str, ...] = ()
    markdown: str | None = None
    html: str | None = None


@dataclass(frozen=True)
class YouSearchResult:
    """One normalized web page or news article."""

    # ``source_type`` lets downstream agents keep web and news evidence apart.
    source_type: str
    rank: int
    url: str
    title: str
    description: str | None
    snippets: tuple[str, ...]
    page_age: str | None
    thumbnail_url: str | None
    favicon_url: str | None
    contents: SearchContents | None
    trace: SourceTrace


@dataclass(frozen=True)
class YouSearchResponse:
    """Normalized result sections plus request-level provenance."""

    web: tuple[YouSearchResult, ...]
    news: tuple[YouSearchResult, ...]
    trace: SourceTrace

    @property
    def all_results(self) -> tuple[YouSearchResult, ...]:
        """Return web and news items in one sequence when separation is unneeded."""

        return self.web + self.news


# An opener follows the shape of ``urllib.request.urlopen``.  Tests can inject a
# tiny fake opener, while production uses the real standard-library function.
Opener = Callable[..., Any]
Clock = Callable[[], datetime]
Sleeper = Callable[[float], None]


class YouSearchClient:
    """Call and normalize the You.com Web Search API.

    Args:
        api_key: Explicit key.  When omitted, ``YDC_API_KEY`` is read from the
            environment, matching You.com's official documentation.
        timeout_seconds: Network timeout for the overall HTTP request.
        max_retries: Extra attempts allowed after HTTP 429 or 5xx responses.
        backoff_seconds: Base delay before retrying; later delays double.
        opener: Injectable ``urlopen``-compatible callable, primarily for tests.
        clock: Injectable clock used to make provenance timestamps deterministic
            in tests.
        sleeper: Injectable replacement for ``time.sleep``, primarily for tests.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        timeout_seconds: float = 20.0,
        max_retries: int = 2,
        backoff_seconds: float = 0.5,
        opener: Opener | None = None,
        clock: Clock | None = None,
        sleeper: Sleeper | None = None,
    ) -> None:
        resolved_key = api_key if api_key is not None else os.getenv(YOU_API_KEY_ENV_VAR)
        if not isinstance(resolved_key, str) or not resolved_key.strip():
            raise YouSearchConfigurationError(
                f"A You.com API key is required. Pass api_key or set {YOU_API_KEY_ENV_VAR}."
            )
        if isinstance(timeout_seconds, bool) or timeout_seconds <= 0:
            raise YouSearchConfigurationError("timeout_seconds must be greater than zero.")
        _require_int_range(max_retries, "max_retries", minimum=0, maximum=10)
        if (
            isinstance(backoff_seconds, bool)
            or not isinstance(backoff_seconds, (int, float))
            or not 0 <= backoff_seconds <= 60
        ):
            raise YouSearchConfigurationError(
                "backoff_seconds must be a number from zero through 60."
            )

        # The key is deliberately private and is never included in exceptions or
        # returned trace data.
        self._api_key = resolved_key.strip()
        self._timeout_seconds = float(timeout_seconds)
        self._max_retries = max_retries
        self._backoff_seconds = float(backoff_seconds)
        self._opener = opener or urlopen
        self._clock = clock or (lambda: datetime.now(UTC))
        self._sleeper = sleeper or time.sleep

    def search(
        self,
        query: str,
        *,
        count: int = 10,
        freshness: str | None = None,
        offset: int = 0,
        country: str | None = None,
        language: str | None = None,
        safesearch: str | None = None,
        knowledge: str | None = None,
        include_domains: Sequence[str] | str | None = None,
        exclude_domains: Sequence[str] | str | None = None,
        boost_domains: Sequence[str] | str | None = None,
        extraction_mode: str | None = None,
        extraction_formats: Sequence[str] | str | None = None,
        crawl_timeout: int | None = None,
    ) -> YouSearchResponse:
        """Search the web and, when You.com detects news intent, live news.

        News does not have a separate endpoint.  It may appear in
        ``response.news`` for a news-oriented query, and an empty tuple is normal.
        Optional arguments mirror the documented POST request fields.  The
        deprecated ``livecrawl`` parameters are intentionally not exposed.
        """

        clean_query = _require_non_empty_string(query, "query")
        _require_int_range(count, "count", minimum=1, maximum=100)
        _require_int_range(offset, "offset", minimum=0, maximum=9)

        included = _normalize_string_list(include_domains, "include_domains")
        excluded = _normalize_string_list(exclude_domains, "exclude_domains")
        boosted = _normalize_string_list(boost_domains, "boost_domains")
        for name, domains in (
            ("include_domains", included),
            ("exclude_domains", excluded),
            ("boost_domains", boosted),
        ):
            if len(domains) > 500:
                raise YouSearchConfigurationError(f"{name} accepts at most 500 domains.")

        # These combinations are rejected by the API with HTTP 422.  Catching
        # them locally gives a beginner a much more useful error message.
        if included and excluded:
            raise YouSearchConfigurationError(
                "include_domains cannot be combined with exclude_domains."
            )
        if included and boosted:
            raise YouSearchConfigurationError(
                "include_domains cannot be combined with boost_domains."
            )

        if safesearch is not None and safesearch not in {"off", "moderate", "strict"}:
            raise YouSearchConfigurationError("safesearch must be 'off', 'moderate', or 'strict'.")

        if crawl_timeout is not None:
            _require_int_range(crawl_timeout, "crawl_timeout", minimum=1, maximum=60)

        extraction = _build_extraction(extraction_mode, extraction_formats)

        # Start with required/default fields, then add optional values only when
        # the caller supplied them.  This lets server defaults continue to work.
        payload: dict[str, Any] = {
            "query": clean_query,
            "count": count,
            "offset": offset,
        }
        _add_optional_text(payload, "freshness", freshness)
        _add_optional_text(payload, "country", country)
        _add_optional_text(payload, "language", language)
        _add_optional_text(payload, "safesearch", safesearch)
        _add_optional_text(payload, "knowledge", knowledge)
        if included:
            payload["include_domains"] = list(included)
        if excluded:
            payload["exclude_domains"] = list(excluded)
        if boosted:
            payload["boost_domains"] = list(boosted)
        if extraction is not None:
            payload["extraction"] = extraction
        if crawl_timeout is not None:
            payload["crawl_timeout"] = crawl_timeout

        document = self._post_json(payload)
        return _parse_response(document, requested_query=clean_query, clock=self._clock)

    def _post_json(self, payload: Mapping[str, Any]) -> Mapping[str, Any]:
        """Send a JSON POST and return its top-level object.

        Rate limits and temporary server failures are common enough that a
        research run should not fail immediately.  We retry only HTTP 429 and
        5xx responses, using a small exponential delay.  Client errors such as
        401 (bad credentials) are returned immediately because retrying them
        would not help.
        """

        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request = Request(
            YOU_SEARCH_ENDPOINT,
            data=body,
            headers={
                "X-API-Key": self._api_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="POST",
        )

        # ``max_retries`` counts retries after the first request.  For example,
        # the default of two allows at most three network attempts in total.
        for attempt in range(self._max_retries + 1):
            try:
                with self._opener(request, timeout=self._timeout_seconds) as response:
                    status = getattr(response, "status", 200)
                    raw_body = response.read()
            except HTTPError as exc:
                if _is_retryable_status(exc.code) and attempt < self._max_retries:
                    # Close the failed response before sleeping and trying again.
                    exc.close()
                    self._sleep_before_retry(attempt)
                    continue

                # Read a small terminal error response when available.  The
                # exact API key is redacted defensively in case a test double or
                # upstream service echoes it in an error body.
                detail = _redact_secret(_safe_error_body(exc), self._api_key)
                suffix = f": {detail}" if detail else ""
                raise YouSearchError(f"You.com search returned HTTP {exc.code}{suffix}") from exc
            except URLError as exc:
                reason = _redact_secret(str(exc.reason), self._api_key)
                raise YouSearchError(f"Could not reach You.com search: {reason}") from exc
            except OSError as exc:
                detail = _redact_secret(str(exc), self._api_key)
                raise YouSearchError(f"Could not reach You.com search: {detail}") from exc

            if isinstance(status, int) and 200 <= status < 300:
                break
            if (
                isinstance(status, int)
                and _is_retryable_status(status)
                and attempt < self._max_retries
            ):
                self._sleep_before_retry(attempt)
                continue
            raise YouSearchError(f"You.com search returned HTTP {status}.")
        else:  # pragma: no cover - the loop always returns, breaks, or raises.
            raise YouSearchError("You.com search exhausted its retry budget.")

        if isinstance(raw_body, bytes):
            text = raw_body.decode("utf-8", errors="replace")
        elif isinstance(raw_body, str):
            # A real urllib response returns bytes, but accepting text makes the
            # boundary friendlier to simple fakes and custom transports.
            text = raw_body
        else:
            raise YouSearchError("You.com search returned an unreadable response body.")

        try:
            decoded = json.loads(text)
        except json.JSONDecodeError as exc:
            raise YouSearchError("You.com search returned invalid JSON.") from exc
        if not isinstance(decoded, Mapping):
            raise YouSearchError("You.com search returned JSON that was not an object.")
        return decoded

    def _sleep_before_retry(self, failed_attempt: int) -> None:
        """Wait between transient failures using bounded exponential backoff."""

        delay = self._backoff_seconds * (2**failed_attempt)
        self._sleeper(delay)


def _parse_response(
    document: Mapping[str, Any],
    *,
    requested_query: str,
    clock: Clock,
) -> YouSearchResponse:
    """Convert loosely typed external JSON into predictable dataclasses."""

    metadata = document.get("metadata")
    if not isinstance(metadata, Mapping):
        metadata = {}

    response_query = _optional_text(metadata.get("query")) or requested_query
    search_uuid = _optional_text(metadata.get("search_uuid"))
    latency = _optional_number(metadata.get("latency"))
    trace = SourceTrace(
        provider="you.com",
        endpoint=YOU_SEARCH_ENDPOINT,
        query=response_query,
        search_uuid=search_uuid,
        latency_seconds=latency,
        retrieved_at=_utc_timestamp(clock()),
    )

    results = document.get("results")
    if not isinstance(results, Mapping):
        results = {}

    web = _parse_section(results.get("web"), source_type="web", trace=trace)
    news = _parse_section(results.get("news"), source_type="news", trace=trace)
    return YouSearchResponse(web=web, news=news, trace=trace)


def _parse_section(
    value: Any,
    *,
    source_type: str,
    trace: SourceTrace,
) -> tuple[YouSearchResult, ...]:
    """Parse one optional result array, skipping malformed non-object entries."""

    if not isinstance(value, list):
        return ()

    parsed: list[YouSearchResult] = []
    for raw_item in value:
        if not isinstance(raw_item, Mapping):
            continue

        # Rank is based on valid objects, not malformed entries that were skipped.
        rank = len(parsed) + 1
        parsed.append(
            YouSearchResult(
                source_type=source_type,
                rank=rank,
                url=_optional_text(raw_item.get("url")) or "",
                title=_optional_text(raw_item.get("title")) or "",
                description=_optional_text(raw_item.get("description")),
                snippets=_string_tuple(raw_item.get("snippets")),
                page_age=_optional_text(raw_item.get("page_age")),
                thumbnail_url=_optional_text(raw_item.get("thumbnail_url")),
                favicon_url=_optional_text(raw_item.get("favicon_url")),
                contents=_parse_contents(raw_item.get("contents")),
                trace=trace,
            )
        )
    return tuple(parsed)


def _parse_contents(value: Any) -> SearchContents | None:
    if not isinstance(value, Mapping):
        return None

    contents = SearchContents(
        highlights=_string_tuple(value.get("highlights")),
        markdown=_optional_text(value.get("markdown")),
        html=_optional_text(value.get("html")),
    )
    # An empty object carries no useful signal, so normalize it to ``None``.
    if not contents.highlights and contents.markdown is None and contents.html is None:
        return None
    return contents


def _build_extraction(
    mode: str | None,
    formats: Sequence[str] | str | None,
) -> dict[str, Any] | None:
    normalized_formats = _normalize_string_list(formats, "extraction_formats")
    if mode is None:
        if normalized_formats:
            raise YouSearchConfigurationError(
                "extraction_formats requires extraction_mode='full_page'."
            )
        return None

    clean_mode = _require_non_empty_string(mode, "extraction_mode")
    if clean_mode not in {"highlights", "full_page"}:
        raise YouSearchConfigurationError("extraction_mode must be 'highlights' or 'full_page'.")
    if clean_mode != "full_page" and normalized_formats:
        raise YouSearchConfigurationError(
            "extraction_formats can only be used with extraction_mode='full_page'."
        )
    if any(value not in {"markdown", "html"} for value in normalized_formats):
        raise YouSearchConfigurationError(
            "extraction_formats may contain only 'markdown' and 'html'."
        )

    extraction: dict[str, Any] = {"extraction_mode": clean_mode}
    if clean_mode == "full_page" and normalized_formats:
        extraction["full_page"] = {"extraction_formats": list(normalized_formats)}
    return extraction


def _normalize_string_list(
    value: Sequence[str] | str | None,
    field_name: str,
) -> tuple[str, ...]:
    """Normalize one string or a string sequence, preserving order and uniqueness."""

    if value is None:
        return ()
    candidates: Sequence[Any] = (value,) if isinstance(value, str) else value

    normalized: list[str] = []
    seen: set[str] = set()
    try:
        iterator = iter(candidates)
    except TypeError as exc:
        raise YouSearchConfigurationError(
            f"{field_name} must be a string or a sequence of strings."
        ) from exc

    for candidate in iterator:
        clean = _require_non_empty_string(candidate, field_name)
        if clean not in seen:
            normalized.append(clean)
            seen.add(clean)
    return tuple(normalized)


def _require_non_empty_string(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise YouSearchConfigurationError(f"{field_name} must be a non-empty string.")
    return value.strip()


def _require_int_range(value: Any, field_name: str, *, minimum: int, maximum: int) -> None:
    # bool is an int subclass in Python, but ``count=True`` is almost certainly a
    # programming mistake, so it is rejected explicitly.
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise YouSearchConfigurationError(
            f"{field_name} must be an integer from {minimum} through {maximum}."
        )


def _add_optional_text(payload: dict[str, Any], key: str, value: str | None) -> None:
    if value is not None:
        payload[key] = _require_non_empty_string(value, key)


def _optional_text(value: Any) -> str | None:
    return value if isinstance(value, str) else None


def _optional_number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def _string_tuple(value: Any) -> tuple[str, ...]:
    # Although the API schema uses arrays, accepting one string prevents an
    # upstream schema drift from turning a useful passage into individual chars.
    if isinstance(value, str):
        return (value,)
    if not isinstance(value, list):
        return ()
    return tuple(item for item in value if isinstance(item, str))


def _utc_timestamp(value: datetime) -> str:
    if value.tzinfo is None:
        # A naive injected clock is interpreted as UTC rather than local time.
        value = value.replace(tzinfo=UTC)
    value = value.astimezone(UTC)
    return value.isoformat().replace("+00:00", "Z")


def _safe_error_body(error: HTTPError) -> str:
    try:
        body = error.read(2_000)
    except (OSError, AttributeError):
        return ""
    if isinstance(body, bytes):
        return body.decode("utf-8", errors="replace").strip()
    return body.strip() if isinstance(body, str) else ""


def _is_retryable_status(status: int) -> bool:
    """Return whether an HTTP status represents a temporary API failure."""

    return status == 429 or 500 <= status <= 599


def _redact_secret(value: str, secret: str) -> str:
    """Prevent credentials from appearing in user-facing adapter errors."""

    return value.replace(secret, "[REDACTED]") if secret else value


__all__ = [
    "YOU_API_KEY_ENV_VAR",
    "YOU_SEARCH_ENDPOINT",
    "SearchContents",
    "SourceTrace",
    "YouSearchClient",
    "YouSearchConfigurationError",
    "YouSearchError",
    "YouSearchResponse",
    "YouSearchResult",
]
