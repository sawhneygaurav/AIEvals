"""Command-line entry points for indexing, running, and inspecting the graph."""

from __future__ import annotations

import argparse
import json
from dataclasses import replace
from pathlib import Path

from .config import Settings
from .graph import build_workflow, create_runtime, run_research
from .rag import BookKnowledgeBase


def _settings(mode: str, book: str | None = None) -> Settings:
    settings = Settings.from_env(mode=mode)  # type: ignore[arg-type]
    if book:
        settings = replace(settings, book_pdf_path=Path(book).expanduser().resolve())
    return settings


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="competitive-scoring",
        description="Run the PNGJL competitive investment-scoring agents.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    index_parser = subparsers.add_parser("ingest-book", help="Build the private local RAG index.")
    index_parser.add_argument("--pdf", help="Path to your licensed Peaceful Investing PDF.")
    index_parser.add_argument(
        "--force", action="store_true", help="Rebuild even if the hash matches."
    )

    run_parser = subparsers.add_parser("run", help="Run the complete LangGraph workflow.")
    run_parser.add_argument("--mode", choices=("demo", "live"), default="demo")
    run_parser.add_argument("--pdf", help="Override BOOK_PDF_PATH for this run.")
    run_parser.add_argument("--output", default="outputs/briefing.md")

    graph_parser = subparsers.add_parser("graph", help="Print the generated Mermaid architecture.")
    graph_parser.add_argument("--mode", choices=("demo", "live"), default="demo")

    args = parser.parse_args()
    settings = _settings(getattr(args, "mode", "demo"), getattr(args, "pdf", None))

    if args.command == "ingest-book":
        knowledge_base = BookKnowledgeBase(
            pdf_path=settings.book_pdf_path,
            index_dir=settings.book_index_dir,
        )
        result = knowledge_base.ensure_index(force=args.force)
        print(json.dumps(result, indent=2))
        return

    if args.command == "graph":
        graph = build_workflow(create_runtime(settings))
        print(graph.get_graph().draw_mermaid())
        return

    briefing, trace = run_research(settings)
    output = Path(args.output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(briefing.markdown, encoding="utf-8")
    json_path = output.with_suffix(".json")
    json_path.write_text(briefing.model_dump_json(indent=2), encoding="utf-8")
    print(f"Wrote {output}")
    print(f"Wrote {json_path}")
    print(f"Completed {len(trace)} trace events; audit passed={briefing.audit.passed}")
    if not briefing.audit.passed:
        # The diagnostic report is still valuable, but a non-zero exit status
        # prevents automation from treating an invalid ranking as success.
        raise SystemExit(2)


if __name__ == "__main__":
    main()
