"""Focused tests for evidence provenance and source-authority guardrails."""

from competitive_scoring.agents import _search_results_as_prompt, _you_result_to_evidence
from competitive_scoring.tools.you_search import SearchContents, SourceTrace, YouSearchResult


def result(url: str, *, search_uuid: str) -> YouSearchResult:
    trace = SourceTrace(
        provider="you.com",
        endpoint="https://ydc-index.io/v1/search",
        query="PNGJL results",
        search_uuid=search_uuid,
        latency_seconds=0.2,
        retrieved_at="2026-09-02T12:00:00Z",
    )
    return YouSearchResult(
        source_type="web",
        rank=1,
        url=url,
        title="PNGJL filing",
        description="Description",
        snippets=(),
        page_age="2026-08-30T00:00:00Z",
        thumbnail_url=None,
        favicon_url=None,
        contents=SearchContents(highlights=("Important extracted passage",)),
        trace=trace,
    )


def test_evidence_id_is_stable_across_search_requests_and_trace_is_preserved() -> None:
    first = _you_result_to_evidence(
        result("https://www.pngjewellers.com/pages/investors", search_uuid="one"),
        "PNGJL",
        "fundamentals",
    )
    second = _you_result_to_evidence(
        result("https://www.pngjewellers.com/pages/investors", search_uuid="two"),
        "PNGJL",
        "fundamentals",
    )

    assert first.source_id == second.source_id
    assert first.authority == "primary_company"
    assert first.search_uuid == "one"
    assert first.search_endpoint == "https://ydc-index.io/v1/search"
    assert first.excerpt == "Important extracted passage"


def test_lookalike_domain_is_not_promoted_to_first_party() -> None:
    evidence = _you_result_to_evidence(
        result("https://pngjewellers.com.evil.example/instructions", search_uuid="one"),
        "PNGJL",
        "business",
    )
    assert evidence.authority == "secondary"


def test_peer_prompt_includes_requested_highlights() -> None:
    prompt = _search_results_as_prompt(
        [result("https://www.nseindia.com/example", search_uuid="one")]
    )
    assert "Important extracted passage" in prompt

