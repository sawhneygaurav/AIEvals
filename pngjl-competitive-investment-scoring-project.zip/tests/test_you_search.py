"""Focused, fully offline tests for the You.com search boundary."""

from __future__ import annotations

import json
import sys
import unittest
from datetime import UTC, datetime
from io import BytesIO
from pathlib import Path
from typing import Self
from unittest.mock import patch
from urllib.error import HTTPError

# The repository uses a ``src`` layout.  Adding it here lets this focused test
# run even before the project has been installed as a package.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from competitive_scoring.tools.you_search import (
    YOU_SEARCH_ENDPOINT,
    YouSearchClient,
    YouSearchConfigurationError,
    YouSearchError,
)


class FakeResponse:
    """Minimal context-manager response with the methods urllib uses."""

    def __init__(self, document: object, *, status: int = 200) -> None:
        self.status = status
        self._body = json.dumps(document).encode("utf-8")

    def read(self) -> bytes:
        return self._body

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_args: object) -> None:
        return None


class InvalidJsonResponse(FakeResponse):
    def read(self) -> bytes:
        return b"this is not JSON"


class RecordingOpener:
    """Return prepared data and remember the request instead of using a network."""

    def __init__(self, response: FakeResponse) -> None:
        self.response = response
        self.request = None
        self.timeout = None

    def __call__(self, request: object, *, timeout: float) -> FakeResponse:
        self.request = request
        self.timeout = timeout
        return self.response


class SequenceOpener:
    """Return or raise prepared outcomes in order and count every attempt."""

    def __init__(self, *outcomes: FakeResponse | Exception) -> None:
        self.outcomes = list(outcomes)
        self.calls = 0

    def __call__(self, _request: object, *, timeout: float) -> FakeResponse:
        del timeout
        self.calls += 1
        outcome = self.outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome


def http_error(status: int, body: str = "") -> HTTPError:
    """Build a realistic urllib HTTP error without making a network call."""

    return HTTPError(
        YOU_SEARCH_ENDPOINT,
        status,
        f"HTTP {status}",
        hdrs=None,
        fp=BytesIO(body.encode("utf-8")),
    )


FIXED_TIME = datetime(2026, 9, 2, 12, 30, tzinfo=UTC)


class YouSearchClientTests(unittest.TestCase):
    def test_posts_official_request_and_parses_web_news_and_trace(self) -> None:
        opener = RecordingOpener(
            FakeResponse(
                {
                    "results": {
                        "web": [
                            {
                                "url": "https://example.com/pricing",
                                "title": "Example pricing",
                                "description": "Current price information",
                                "snippets": ["A useful excerpt"],
                                "page_age": "2026-09-01T08:00:00Z",
                                "thumbnail_url": "https://example.com/thumb.png",
                                "favicon_url": "https://example.com/favicon.ico",
                                "contents": {"markdown": "# Pricing"},
                            }
                        ],
                        "news": [
                            {
                                "url": "https://news.example.com/story",
                                "title": "Store opening",
                                "page_age": "2026-09-02T07:00:00Z",
                            }
                        ],
                    },
                    "metadata": {
                        "query": "P N Gadgil Jewellers latest news",
                        "search_uuid": "search-123",
                        "latency": 0.42,
                    },
                }
            )
        )
        client = YouSearchClient(
            api_key="test-secret",
            timeout_seconds=7,
            opener=opener,
            clock=lambda: FIXED_TIME,
        )

        response = client.search(
            "P N Gadgil Jewellers latest news",
            count=5,
            freshness="month",
            country="IN",
            language="EN",
            include_domains=["pngjewellers.com", "example.com", "example.com"],
            extraction_mode="full_page",
            extraction_formats=["markdown"],
            crawl_timeout=15,
        )

        # These assertions prove the adapter uses the current POST endpoint and
        # API-key header, while the fake opener guarantees no network was used.
        request = opener.request
        self.assertIsNotNone(request)
        self.assertEqual(request.get_method(), "POST")
        self.assertEqual(request.full_url, YOU_SEARCH_ENDPOINT)
        headers = {key.lower(): value for key, value in request.header_items()}
        self.assertEqual(headers["x-api-key"], "test-secret")
        self.assertEqual(headers["content-type"], "application/json")
        self.assertEqual(opener.timeout, 7.0)

        sent = json.loads(request.data.decode("utf-8"))
        self.assertEqual(sent["query"], "P N Gadgil Jewellers latest news")
        self.assertEqual(sent["count"], 5)
        self.assertEqual(sent["freshness"], "month")
        self.assertEqual(sent["country"], "IN")
        self.assertEqual(sent["include_domains"], ["pngjewellers.com", "example.com"])
        self.assertEqual(
            sent["extraction"],
            {
                "extraction_mode": "full_page",
                "full_page": {"extraction_formats": ["markdown"]},
            },
        )

        self.assertEqual(len(response.web), 1)
        self.assertEqual(len(response.news), 1)
        self.assertEqual(response.web[0].source_type, "web")
        self.assertEqual(response.news[0].source_type, "news")
        self.assertEqual(response.web[0].contents.markdown, "# Pricing")
        self.assertEqual(response.news[0].snippets, ())
        self.assertEqual(response.trace.search_uuid, "search-123")
        self.assertEqual(response.trace.latency_seconds, 0.42)
        self.assertEqual(response.trace.retrieved_at, "2026-09-02T12:30:00Z")
        # Each result carries the same immutable trace, so provenance survives
        # when a downstream agent stores an individual source by itself.
        self.assertIs(response.web[0].trace, response.trace)
        self.assertEqual(len(response.all_results), 2)

    def test_missing_or_wrongly_typed_optional_sections_are_safe(self) -> None:
        opener = RecordingOpener(
            FakeResponse(
                {
                    "results": {
                        "web": None,
                        "news": [
                            "not an object",
                            {
                                "title": "Sparse article",
                                "snippets": "one fallback snippet",
                                "contents": {"highlights": [3, "Relevant passage"]},
                            },
                        ],
                    },
                    "metadata": "not an object",
                }
            )
        )
        response = YouSearchClient(
            api_key="test-secret", opener=opener, clock=lambda: FIXED_TIME
        ).search("sparse response")

        self.assertEqual(response.web, ())
        self.assertEqual(len(response.news), 1)
        article = response.news[0]
        self.assertEqual(article.rank, 1)
        self.assertEqual(article.url, "")
        self.assertIsNone(article.description)
        self.assertEqual(article.snippets, ("one fallback snippet",))
        self.assertEqual(article.contents.highlights, ("Relevant passage",))
        # If response metadata is absent, the requested query remains traceable.
        self.assertEqual(response.trace.query, "sparse response")
        self.assertIsNone(response.trace.search_uuid)

    def test_entire_results_object_may_be_absent(self) -> None:
        opener = RecordingOpener(FakeResponse({"metadata": {"latency": "unknown"}}))
        response = YouSearchClient(
            api_key="test-secret", opener=opener, clock=lambda: FIXED_TIME
        ).search("no matches")

        self.assertEqual(response.web, ())
        self.assertEqual(response.news, ())
        self.assertIsNone(response.trace.latency_seconds)

    def test_reads_canonical_environment_variable(self) -> None:
        opener = RecordingOpener(FakeResponse({}))
        with patch.dict("os.environ", {"YDC_API_KEY": "from-environment"}, clear=True):
            YouSearchClient(opener=opener).search("environment key")

        headers = {key.lower(): value for key, value in opener.request.header_items()}
        self.assertEqual(headers["x-api-key"], "from-environment")

    def test_rejects_missing_key_and_conflicting_domain_filters(self) -> None:
        with (
            patch.dict("os.environ", {}, clear=True),
            self.assertRaisesRegex(YouSearchConfigurationError, "YDC_API_KEY"),
        ):
            YouSearchClient()

        opener = RecordingOpener(FakeResponse({}))
        client = YouSearchClient(api_key="test-secret", opener=opener)
        with self.assertRaisesRegex(YouSearchConfigurationError, "cannot be combined"):
            client.search(
                "invalid filters",
                include_domains=["allowed.example"],
                exclude_domains=["blocked.example"],
            )
        # Validation happens before the transport boundary.
        self.assertIsNone(opener.request)

    def test_invalid_json_becomes_clear_adapter_error(self) -> None:
        opener = RecordingOpener(InvalidJsonResponse({}))
        client = YouSearchClient(api_key="test-secret", opener=opener)

        with self.assertRaisesRegex(YouSearchError, "invalid JSON"):
            client.search("bad response")

    def test_retries_429_and_5xx_with_exponential_backoff(self) -> None:
        # urllib raises HTTPError for non-2xx responses in production.  The
        # second outcome covers a custom opener that returns a status instead.
        opener = SequenceOpener(
            http_error(429, "rate limited"),
            FakeResponse({"temporary": True}, status=503),
            FakeResponse({"results": {"web": []}}),
        )
        delays: list[float] = []
        client = YouSearchClient(
            api_key="test-secret",
            opener=opener,
            max_retries=2,
            backoff_seconds=0.25,
            sleeper=delays.append,
        )

        response = client.search("temporary failures")

        self.assertEqual(opener.calls, 3)
        self.assertEqual(delays, [0.25, 0.5])
        self.assertEqual(response.web, ())

    def test_retry_budget_is_bounded_and_error_redacts_api_key(self) -> None:
        secret = "never-print-this-key"
        opener = SequenceOpener(
            http_error(500, "temporary"),
            http_error(502, "temporary"),
            http_error(503, f"upstream echoed {secret}"),
        )
        delays: list[float] = []
        client = YouSearchClient(
            api_key=secret,
            opener=opener,
            max_retries=2,
            backoff_seconds=1,
            sleeper=delays.append,
        )

        with self.assertRaises(YouSearchError) as caught:
            client.search("bounded retries")

        message = str(caught.exception)
        self.assertEqual(opener.calls, 3)
        self.assertEqual(delays, [1.0, 2.0])
        self.assertIn("HTTP 503", message)
        self.assertIn("[REDACTED]", message)
        self.assertNotIn(secret, message)

    def test_non_transient_http_error_is_not_retried(self) -> None:
        opener = SequenceOpener(http_error(401, "invalid credentials"))
        delays: list[float] = []
        client = YouSearchClient(
            api_key="test-secret",
            opener=opener,
            sleeper=delays.append,
        )

        with self.assertRaisesRegex(YouSearchError, "HTTP 401"):
            client.search("bad credentials")

        self.assertEqual(opener.calls, 1)
        self.assertEqual(delays, [])

    def test_retry_options_are_validated_before_any_request(self) -> None:
        with self.assertRaisesRegex(YouSearchConfigurationError, "max_retries"):
            YouSearchClient(api_key="test-secret", max_retries=11)
        with self.assertRaisesRegex(YouSearchConfigurationError, "backoff_seconds"):
            YouSearchClient(api_key="test-secret", backoff_seconds=-0.1)


if __name__ == "__main__":
    unittest.main()
