"""Offline tests for the OpenAI Responses API boundary.

The fake client below has the same tiny surface that ``StructuredLLM`` uses, so
these tests never make a network request and never require a real API key.
"""

from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace

import pytest
from openai import OpenAIError
from pydantic import BaseModel

from competitive_scoring.llm import REPAIR_INSTRUCTION, StructuredLLM


class ExampleAnswer(BaseModel):
    """Small schema that makes success and validation failure easy to see."""

    company: str
    score: int


@dataclass
class FakeResponse:
    """Minimal substitute for the SDK's response object."""

    status: str = "completed"
    output_text: str | None = '{"company": "PNGJL", "score": 82}'
    incomplete_details: object | None = None


class FakeResponsesAPI:
    """Return or raise prepared outcomes in order and record every request."""

    def __init__(self, *outcomes: FakeResponse | Exception) -> None:
        self.outcomes = list(outcomes)
        self.calls: list[dict[str, object]] = []

    def create(self, **kwargs: object) -> FakeResponse:
        self.calls.append(kwargs)
        outcome = self.outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome


def make_llm(*outcomes: FakeResponse | Exception, max_attempts: int = 2) -> tuple:
    """Build the wrapper around a fake ``client.responses.create`` method."""

    responses_api = FakeResponsesAPI(*outcomes)
    fake_client = SimpleNamespace(responses=responses_api)
    llm = StructuredLLM(
        api_key="test-key",
        model="test-model",
        client=fake_client,
        max_attempts=max_attempts,
    )
    return llm, responses_api


def test_success_uses_json_schema_and_never_stores_the_response() -> None:
    llm, api = make_llm(FakeResponse())

    answer = llm.generate(
        schema=ExampleAnswer,
        instructions="Return an investment score.",
        prompt="Score PNGJL.",
    )

    assert answer == ExampleAnswer(company="PNGJL", score=82)
    assert len(api.calls) == 1
    request = api.calls[0]
    assert request["model"] == "test-model"
    assert request["input"] == "Score PNGJL."
    assert request["store"] is False
    assert request["text"] == {
        "format": {
            "type": "json_schema",
            "name": "exampleanswer",
            "schema": ExampleAnswer.model_json_schema(),
            "strict": False,
        }
    }


@pytest.mark.parametrize(
    "bad_response",
    [
        FakeResponse(status="incomplete", incomplete_details={"reason": "max_output_tokens"}),
        FakeResponse(output_text="   "),
        FakeResponse(output_text="not JSON"),
        FakeResponse(output_text='{"company": "PNGJL", "score": "not-a-number"}'),
    ],
    ids=["incomplete", "empty", "malformed-json", "schema-invalid"],
)
def test_invalid_output_is_retried_with_a_repair_instruction(
    bad_response: FakeResponse,
) -> None:
    llm, api = make_llm(bad_response, FakeResponse())

    answer = llm.generate(
        schema=ExampleAnswer,
        instructions="Return an investment score.",
        prompt="Score PNGJL.",
    )

    assert answer.score == 82
    assert len(api.calls) == 2
    assert REPAIR_INSTRUCTION.strip() not in str(api.calls[0]["instructions"])
    assert REPAIR_INSTRUCTION.strip() in str(api.calls[1]["instructions"])
    # Privacy is not weakened during a retry.
    assert all(call["store"] is False for call in api.calls)


def test_api_exception_is_retried_and_can_recover() -> None:
    llm, api = make_llm(OpenAIError("temporary API problem"), FakeResponse())

    answer = llm.generate(
        schema=ExampleAnswer,
        instructions="Return an investment score.",
        prompt="Score PNGJL.",
    )

    assert answer.company == "PNGJL"
    assert len(api.calls) == 2
    assert REPAIR_INSTRUCTION.strip() in str(api.calls[1]["instructions"])


def test_failure_stops_at_the_configured_attempt_limit() -> None:
    llm, api = make_llm(
        FakeResponse(output_text="bad JSON"),
        RuntimeError("service unavailable"),
    )

    with pytest.raises(RuntimeError, match="failed after 2 attempts") as caught:
        llm.generate(
            schema=ExampleAnswer,
            instructions="Return an investment score.",
            prompt="Score PNGJL.",
        )

    assert len(api.calls) == 2
    assert isinstance(caught.value.__cause__, RuntimeError)
    assert "service unavailable" in str(caught.value.__cause__)


def test_max_attempts_must_be_positive() -> None:
    with pytest.raises(ValueError, match="at least 1"):
        StructuredLLM(
            api_key="test-key",
            model="test-model",
            client=SimpleNamespace(),
            max_attempts=0,
        )
